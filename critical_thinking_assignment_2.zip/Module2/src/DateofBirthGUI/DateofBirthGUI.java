package DateofBirthGUI;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.Period;
import java.awt.event.ActionEvent;
import java.awt.Insets;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;


public class DateofBirthGUI extends JFrame implements ActionListener {
	private JLabel monthLabel; //label for birth month
	private JLabel dayLabel; // label for birth day
	private JLabel yearLabel; // label for birth year
	private JLabel userAge; // label for the age output
	private JTextField usermonthField; //allows to enter month
	private JTextField userdateField; //allows to enter day
	private JTextField useryearField; //allows to enter year
	private JTextField userageField; // showing the age output
	private JButton calcButton; //triggers age calculation
	
 DateofBirthGUI() {	//declaring a constructor of the class
		GridBagConstraints layoutConst = null; 
		setTitle("Age Calculator"); //Title of frame
		
		monthLabel = new JLabel("Enter the month you were born (numerical): ");
		dayLabel = new JLabel("Enter the day you were born: ");
		yearLabel = new JLabel("Enter the year you were born: ");
		userAge = new JLabel("Your Age:");
		
		usermonthField = new JTextField(15);
		usermonthField.setEditable(true);
	
		userdateField = new JTextField(15);
		userdateField.setEditable(true);
		
		useryearField = new JTextField(15);
		useryearField.setEditable(true);
		
		userageField = new JTextField(15);
		userageField.setEditable(false);
	
		calcButton = new JButton("How old are you?"); //labeling my button
		calcButton.addActionListener (this); //action listener triggering this class when button is clicked
		
		setLayout(new GridBagLayout()); //using gridbaglayout
		layoutConst = new GridBagConstraints();
		
		layoutConst.gridx = 0;
		layoutConst.gridy = 0;
		layoutConst.insets = new Insets(10,10,10,10);
		add(monthLabel, layoutConst); //adding month label to panel
		
		layoutConst.gridx = 1;
		layoutConst.gridy = 0;
		layoutConst.insets = new Insets(10,10,10,10);
		add(usermonthField, layoutConst); //adding month output to panel		

		layoutConst.gridx = 0;
		layoutConst.gridy = 1;
		layoutConst.insets = new Insets(10,10,10,10);
		add(dayLabel, layoutConst); //adding day label to panel		

		layoutConst.gridx = 1;
		layoutConst.gridy = 1;
		layoutConst.insets = new Insets(10,10,10,10);
		add(userdateField,layoutConst); //adding date output to panel		

		layoutConst.gridx = 0;
		layoutConst.gridy = 2;
		layoutConst.insets = new Insets(10,10,10,10);
		add(yearLabel, layoutConst); //adding year label to label panel
		
		layoutConst.gridx = 1;
		layoutConst.gridy = 2;
		layoutConst.insets = new Insets(10,10,10,10);
		add(useryearField,layoutConst); //adding year output to panel		

		layoutConst.gridx = 0;
		layoutConst.gridy = 3;
		layoutConst.insets = new Insets(10,10,10,10);
		add(calcButton, layoutConst); //adding calculation button
		
		layoutConst.gridx = 0;
		layoutConst.gridy = 4;
		layoutConst.insets = new Insets(10,10,10,10);
		add(userAge,layoutConst); //adding user age label to panel		

		layoutConst.gridx = 1;
		layoutConst.gridy = 4;
		layoutConst.insets = new Insets(10,10,10,10);
		add(userageField, layoutConst); //adding age output to label panel
		
 }

 
 	@Override
	public void actionPerformed (ActionEvent e) {
 		int day = Integer.parseInt(usermonthField.getText()); //obtaining input
 		int month = Integer.parseInt(userdateField.getText());
 		int year = Integer.parseInt(useryearField.getText());
 		
 		LocalDate birthDate = LocalDate.of(year, day, month);	
 		LocalDate today = LocalDate.now();
		int years = Period.between(birthDate, today).getYears(); //calculation between DOB and today's date
		userageField.setText(String.valueOf(years));
		
	}	
		public static void main(String[] args) {
			DateofBirthGUI myFrame = new DateofBirthGUI();
			myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			myFrame.pack();
			myFrame.setVisible(true); //make GUI visible 
			
	}

}
