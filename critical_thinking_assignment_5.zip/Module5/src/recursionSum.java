import java.util.Scanner;


public class recursionSum {
	public static int sumNumbers(int arr[], int length) {
		if (length == -1) { //base case
			return 0;
		}
		else { //calculate total sum
			return arr[length] + sumNumbers(arr, length - 1);
		}		
	}
	
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		
		int i; //initializing i
		int n = 5; //5 user input 
		int totalSum = 0; 
		
	System.out.println("Enter 5 numbers to get the sum");
	
	int arr[] = new int [n] ;
	for(i = 0; i < n; i++) { //starting a 0 incrementing to 4 
	System.out.println("Your entry number " + (i + 1) + " is ");
	
	arr[i] = scnr.nextInt(); //getting user input into array
	
	}
	totalSum = sumNumbers(arr, n - 1); 
	System.out.println("The total of " + n
			+ " inputs are: " + totalSum);
	
	
		
	}

}
