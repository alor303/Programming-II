
/* A = 1/2 * B * H
 * P = Side + Base + Side (a + b + c)
 */
public class Triangle extends Shape {
	private double side1;
	private double base;
	private double side2;

public Triangle (double side1, double base, double side2) { //creating constructor
	this.side1 = side1;
	this.base = base;
	this.side2 = side2;
}
@Override
double calculateArea() { //area of triangle
	double s = (side1 + base + side2)/2;
	return Math.sqrt(s *(s - side1) * (s - base) * (s - side2));
}
@Override
double calculateParameter () { //parameter of triangle
	return side1 + base + side2;
}
public String toString() { //toString method
	return side1 + ", " + base + ", " + side2;
}
}