import java.util.ArrayList;

public class ShapeArray {
	public static void main(String[] args) {
		ArrayList<Shape> shapeArray = new ArrayList<Shape>();
		
		Rectangle rectangle = new Rectangle (6, 9);
		shapeArray.add(rectangle);
		
		Circle circle = new Circle (4);
		shapeArray.add(circle);
		
		Triangle triangle = new Triangle (25, 30, 15);
		shapeArray.add(triangle);
		
		for(Shape shape : shapeArray) {
		System.out.println("The area of shape is : " + shape.calculateArea() + " and the parameter is: " + shape.calculateParameter());
	
		}
		

	}

}
