

/* A = W*L
 * P = L + L + W + W
 */
public class Rectangle extends Shape {
	private double width;
	private double height;
	
public Rectangle(double width, double height) { //creating constructor
	this.width = width;
	this.height = height;
}
	

double calculateArea() { //calculating area
	return width * height;
}
@Override 
double calculateParameter () { //calculating parameter
	return 2.0 * (width * height);
}
public String toString() { //toString method
	return width + ", " + height;

}}

