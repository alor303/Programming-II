import static java.lang.Math.PI;

/* A = PI *R squared
 * P = 2 * PI * R
 */

public class Circle extends Shape {
	private double radius;
	
public Circle (double radius) { //creating constructor
	this.radius = radius;
	
}
@Override
double calculateArea() { //calculating area using Math.PI
	return Math.PI *radius * radius;
}	

@Override
double calculateParameter () { //calculating parameter
	return 2.0 * Math.PI * radius;
}
public String toString() { //toString method
	return radius + ", ";

}
}