
public abstract class Shape {


	abstract double calculateArea(); //abstract methods
	abstract double calculateParameter();
	
}
