
public class printShapeDetails {

	public static void main(String[] args) {
		
	//rectangle output
	double height = 5;
	double width = 10;
	
	Shape printRectangle = new Rectangle (width, height);
	 System.out.println("The area of your rectangle is: " + printRectangle.calculateArea()); //using abstract method
	 System.out.println("The parameter of your rectangle is: " + printRectangle.calculateParameter());
	 

	//circle output
	 double radius = 6;
	
	 Shape printCircle = new Circle (radius);
	 System.out.println("\r\n" + "The area of your circle is: " + printCircle.calculateArea()); 
	 System.out.println("The parameter of your circle is: " + printCircle.calculateParameter());

	 //triangle output
	 double side1 = 20;
	 double side2 = 15;
	 double base = 12;
	 
	 Shape printTriangle = new Triangle (side1, base, side2);
	 System.out.println("\r\n" + "The area of your triangle is: " + printTriangle.calculateArea());
	 System.out.println("The parameter of your triangle is: " + printTriangle.calculateParameter());
	 
	}

}
