 
public class EmployeeSummary {

	public static void main(String[] args) {
		Employee currentEmployee = new Employee ();
		Manager currentManager = new Manager ();
		
		currentEmployee.setFullName ("Lily", "Yang");
		currentEmployee.setemployeeID (1234);
		currentEmployee.setSalary (98564.23);
		currentManager.setDepartmentA("Sales");
	
		
		currentEmployee.printSummary();
	
		

	}

}
