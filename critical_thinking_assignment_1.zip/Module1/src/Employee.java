
public class Employee { //superclass
	protected String firstName;
	protected String lastName;
	protected int employeeIdentification;
	protected double employeeSalary = 0;
	
	
	public void setFullName(String firstName, String lastName) {
			this.firstName = firstName;
			this.lastName = lastName;		
	}
	
	public void setemployeeID(int empID) {
			this.employeeIdentification = empID;
	}
	public void setSalary (double empSalary) {
			this.employeeSalary = empSalary;
			
	}
	public String getfirstName() {
		return firstName;
	}
	public String getlastName() {
		return lastName;
	}
	public int getemployeeIdentification() {
		return employeeIdentification;
	}
	public double employeeSalary() {
		return employeeSalary;
	}
	
	public void printSummary() {
		System.out.println ("Firstname: " + firstName);
		System.out.println("Lastname: " + lastName);
		System.out.println("Employee ID: " + employeeIdentification);
		System.out.println("Employee Salary: " + employeeSalary);
		
	}

	
	}


