
public class Manager extends Employee{
	
		
		public void setDepartmentA (String DepartmentA) {
			companyDepartmentA = DepartmentA;
			
		}
	@Override
	public void printSummary () { 
		System.out.println("Company Department: " + companyDepartmentA);
	
	}
	private String companyDepartmentA;
		
	}


