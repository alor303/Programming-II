import java.util.Scanner;
import java.util.Collections;
import java.util.LinkedList;
import java.io.PrintWriter;


public class studentRecords {
	
	public static double getGPA() throws Exception { //validating my GPA input to make sure it is a double 
		Scanner scnr = new Scanner(System.in);
		double studentGPA = 0;	//initializing variable	
			
		try {
			studentGPA = Double.parseDouble(scnr.next()); //ensuring input is a double or gets converted into a double  
		}catch (Exception e) {
			System.out.println("INVALID INPUT"); //if output is a letter print this error message
		}
		return studentGPA;
	}
	
	
	public static void main(String[] args) throws Exception { 
		Scanner scnr = new Scanner(System.in);
		LinkedList<Student> student = new LinkedList<Student>(); //initializing Linked List data structure
		
		Student studentData;
		String userCommand;
		String inputName;
		String inputAddress; 
		double inputGPA;
			
		do {
			System.out.print("Enter command ('n' to add a new student, 'e' export data onto a notepad, 'q' to quit): "); 
			userCommand = scnr.nextLine();
			
			if(userCommand.equals("n")) { //prompting user to add new student information in the following format
			
				System.out.print("First and Last name: ");
				inputName = scnr.nextLine();
				System.out.print("Address: ");
				inputAddress = scnr.nextLine();			
				System.out.print("Student grade point average (enter in decimal format on a 4.0 scale): \n");
				inputGPA = getGPA();	
				
				studentData = new Student(inputName, inputAddress, inputGPA); //adding input into linked list 
				student.add(studentData);	
		
		}
			else if (userCommand.equals("e")) { //exporting student information into a notepad
				Collections.sort(student); //sorting student name alphabetically
			
			PrintWriter writer = new PrintWriter("LinkedListStudent.txt"); //creating txt document named LinkedListStudent
			writer.print("Student Records:\n");
			for(Student Student: student) { //looping through linked list to print on txt document
				writer.print(Student);
			}
			writer.close();
			System.out.println("printing your student data onto a notepad. Search your files for it!");
		}

		}while (!userCommand.equals("q")); { //ending program
			System.out.println("You have closed the program.");
			scnr.close(); //closing scanner
		}
		
	}
		
		
}	

	
			
