
public class Student implements Comparable<Student> { 

		private String name; 
		private String address;
		double GPA;
		
	public Student(String name, String address, double GPA) { //initializing constructor 
		this.name = name;
		this.address = address;
		this.GPA = GPA;
	}
	public String getname() { //getters 
		return name;
	}
	public String getaddress () {
		return address;
	}
	public double getGPA() {
		return GPA;
	}
	
	public void setname(String name) { //setters
		this.name = name;
	}
	public void setaddress(String address) {
		this.address = address;
	}
	public void setGPA(double GPA) {
		this.GPA = GPA;
	}
	@Override
	public int compareTo(Student N) { //using this to compare and sort by name alphabetically.
		return this.name.compareTo(N.name);
	}
	@Override
		public String toString() { //converting all variables to string and arranging output format of data
			return "\nName: " + this.name + 
				"\nAddress: " + this.address + 
				"\nGrade Point Average: " + this.GPA + "\n";
	}

}


